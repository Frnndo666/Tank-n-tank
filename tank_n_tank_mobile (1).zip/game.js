
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let tank = { x: 400, y: 500, width: 40, height: 40, speed: 5 };
let bullets = [];
let moveLeft = false, moveRight = false, shooting = false;

document.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft") moveLeft = true;
    if (e.key === "ArrowRight") moveRight = true;
    if (e.key === " ") shooting = true;
});
document.addEventListener("keyup", e => {
    if (e.key === "ArrowLeft") moveLeft = false;
    if (e.key === "ArrowRight") moveRight = false;
    if (e.key === " ") shooting = false;
});

// Touch controls
document.getElementById("left").addEventListener("touchstart", () => moveLeft = true);
document.getElementById("left").addEventListener("touchend", () => moveLeft = false);
document.getElementById("right").addEventListener("touchstart", () => moveRight = true);
document.getElementById("right").addEventListener("touchend", () => moveRight = false);
document.getElementById("shoot").addEventListener("touchstart", () => shooting = true);
document.getElementById("shoot").addEventListener("touchend", () => shooting = false);

function update() {
    if (moveLeft) tank.x -= tank.speed;
    if (moveRight) tank.x += tank.speed;
    if (shooting && bullets.length < 5) {
        bullets.push({ x: tank.x + tank.width/2 - 2, y: tank.y, speed: 7 });
    }
    bullets.forEach(bullet => bullet.y -= bullet.speed);
    bullets = bullets.filter(bullet => bullet.y > 0);
}

function drawTank() {
    ctx.fillStyle = "green";
    ctx.fillRect(tank.x, tank.y, tank.width, tank.height);
}

function drawBullets() {
    ctx.fillStyle = "yellow";
    bullets.forEach(bullet => {
        ctx.fillRect(bullet.x, bullet.y, 4, 10);
    });
}

function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    update();
    drawTank();
    drawBullets();
    requestAnimationFrame(loop);
}

loop();
